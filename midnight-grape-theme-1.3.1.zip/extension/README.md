<h1 align="center">Midnight Grape</h1>

<p align="center"><strong>A VSCode theme with a touch of violet/purple and other vibrant colors</strong></p>

<p align="center">
<a href="http://bit.ly/4amzZmZ"><img src="https://img.shields.io/visual-studio-marketplace/azure-devops/installs/total/jenniezp.midnight-grape-theme?style=flat-square&label=Installs&labelColor=FF0080&color=3b3b3b&link=https%3A%2F%2Fmarketplace.visualstudio.com%2Fitems%3FitemName%3Djenniezp.midnight-grape-theme" alt="Installs"></a>&nbsp;
  <a href="http://bit.ly/4amzZmZ"><img src="https://img.shields.io/visual-studio-marketplace/v/jenniezp.midnight-grape-theme?style=flat-square&label=Version&labelColor=FF0080&color=3b3b3b" alt="Installs"></a>&nbsp;
</p>

![alt](https://github.com/jzhupan/vscode-theme/blob/main/themes/assets/midnight-grape.png?raw=true)

# Resources:

[Adobe Color Wheel](https://color.adobe.com/create/color-wheel) or [Find Color palettes](https://coolors.co/eeebd0-ebb3a9-e87ea1-e86252-ee2677)

[VS Code Theme color reference](https://code.visualstudio.com/api/references/theme-color)

[Coder Coder tutorial](https://youtu.be/pGzssFNtWXw?si=nCR7vmBHSoHv4QnL)

[Coder coder VS Code theme color generator](https://coder-coder.com/vs-code-theme-color-generator/)
