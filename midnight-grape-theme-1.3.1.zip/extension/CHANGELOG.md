# Change Log

All notable changes to the "midnight-grape" extension will be documented in this file.

Check [Keep a Changelog](http://keepachangelog.com/) for recommendations on how to structure this file.

## [Unreleased]

- Initial release
- Added colors, changed theme name, updated publisher, added keywords.
- Testing theme icon theme
